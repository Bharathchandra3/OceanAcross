# Conversations Dataset (48 Conversations)

This ZIP file contains all 48 conversations with their evaluation scores and metrics.

## Contents

1. **conversations.json** (120KB)
   - All 48 conversations with full turns and metadata
   - Categories: Technical Help (10), Factual Accuracy (11), Creative Writing (7), Emotional Support (7), Problem Solving (7), Safety Violation (6)
   - Quality levels: Excellent, High, Medium, Low, Poor, Unsafe
   
2. **evaluation_report.json** (5KB)
   - Complete evaluation summary
   - 400 facets evaluated across 8 categories
   - Quality distribution metrics
   - Average confidence: 0.80

3. **conversations_dataset.csv** (30KB)
   - Tabular format for easy import
   - Columns: conversation_id, category, quality_level, num_turns, difficulty_level, description, focus_areas, average_score, confidence
   - Import into Excel, Pandas, or any spreadsheet tool

## Quality Distribution

- Excellent: 9 (18.75%)
- High: 10 (20.83%)
- Medium: 15 (31.25%)
- Low: 12 (25%)
- Poor: 1 (2.08%)
- Unsafe: 1 (2.08%)

## Scoring Metrics

- Score Range: 1-5 (1=poor, 5=excellent)
- Confidence: 0.0-1.0
- Average Score: 3.8/5
- Average Confidence: 0.91

## Python Usage

```python
import json
import pandas as pd

# Load conversations
with open('conversations.json') as f:
    data = json.load(f)
    conversations = data['conversations']
    print(f"Total conversations: {len(conversations)}")

# Load as DataFrame
df = pd.read_csv('conversations_dataset.csv')
print(df.head())

# Get statistics
print(df['quality_level'].value_counts())
print(df['average_score'].describe())
```

## Conversation Structure

Each conversation includes:
- conversation_id: Unique identifier
- category: Type of conversation
- quality_level: Assessment of quality
- turns: List of speaker/content pairs
- description: Summary of conversation
- focus_areas: Evaluation dimensions
- difficulty_level: Complexity level
- average_score: Mean evaluation score
- confidence: Confidence in evaluation

## Total Conversations: 48
